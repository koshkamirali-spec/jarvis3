import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/services/ocr_service.dart';
import 'package:share_plus/share_plus.dart';

class OcrScreen extends StatefulWidget { const OcrScreen({super.key}); @override State<OcrScreen> createState()=>_OcrScreenState(); }
class _OcrScreenState extends State<OcrScreen> {
 final _picker=ImagePicker(); final _ocr=OcrService(); File? _image; String _text=''; bool _busy=false;
 Future<void> _pick(ImageSource source) async { final x=await _picker.pickImage(source:source,imageQuality:90); if(x==null)return; setState(()=>_busy=true); try { final text=await _ocr.readText(File(x.path)); if(!mounted)return; setState((){_image=File(x.path);_text=text.isEmpty?'متنی در تصویر پیدا نشد.':text;}); } catch(e){ if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('خطا در خواندن تصویر: $e'))); } finally {if(mounted)setState(()=>_busy=false);} }
 @override void dispose(){_ocr.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('استخراج متن از تصویر (OCR)')),body:ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Expanded(child:OutlinedButton.icon(onPressed:_busy?null:()=>_pick(ImageSource.camera),icon:const Icon(Icons.camera_alt),label:const Text('دوربین'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:_busy?null:()=>_pick(ImageSource.gallery),icon:const Icon(Icons.photo),label:const Text('گالری')))]),if(_busy)const Padding(padding:EdgeInsets.all(20),child:Center(child:CircularProgressIndicator())),if(_image!=null)ClipRRect(borderRadius:BorderRadius.circular(16),child:Image.file(_image!,height:190,fit:BoxFit.cover)),const SizedBox(height:16),const Text('متن استخراج‌شده (پشتیبانی اصلی: حروف لاتین)',style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),const SizedBox(height:8),SelectableText(_text.isEmpty?'یک تصویر انتخاب کن تا متن آن به‌صورت محلی استخراج شود. موتور فعلی برای متن لاتین مناسب‌تر است و تشخیص فارسی تضمین‌شده نیست.':_text),if(_text.isNotEmpty)Align(alignment:Alignment.centerLeft,child:Wrap(spacing:8,children:[TextButton.icon(onPressed:()=>Share.share(_text),icon:const Icon(Icons.share),label:const Text('اشتراک‌گذاری')),TextButton.icon(onPressed:()=>setState(()=>_text=''),icon:const Icon(Icons.delete_outline),label:const Text('پاک‌کردن'))]))]));
}
