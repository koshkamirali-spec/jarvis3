import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/services/device_bridge.dart';

class DeviceAccessScreen extends StatefulWidget {
  const DeviceAccessScreen({super.key});
  @override
  State<DeviceAccessScreen> createState() => _DeviceAccessScreenState();
}

class _DeviceAccessScreenState extends State<DeviceAccessScreen> {
  final bridge = JarvisDeviceBridge();
  bool loading = true;
  bool enabled = false;
  List<Map<String, String>> notifications = [];
  final packageController = TextEditingController();

  @override
  void initState() { super.initState(); _refresh(); }
  @override
  void dispose() { packageController.dispose(); super.dispose(); }

  Future<void> _refresh() async {
    if (!bridge.supported) { setState(() { loading = false; }); return; }
    try {
      final value = await bridge.hasNotificationAccess();
      final items = value ? await bridge.activeNotifications() : <Map<String, String>>[];
      if (mounted) setState(() { enabled = value; notifications = items; loading = false; });
    } catch (_) { if (mounted) setState(() { loading = false; }); }
  }

  Future<void> _openSettings() async {
    await bridge.openNotificationAccessSettings();
    await Future<void>.delayed(const Duration(milliseconds: 700));
    await _refresh();
  }

  Future<void> _launchApp() async {
    final package = packageController.text.trim();
    if (package.isEmpty) return;
    try {
      final opened = await bridge.openApp(package);
      if (mounted && !opened) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برنامه‌ای با این شناسه پیدا نشد.')));
    } on PlatformException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'اجرای برنامه ناموفق بود.')));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('دسترسی‌های دستگاه'), actions: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh))]),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      if (!bridge.supported) const Card(child: ListTile(title: Text('فقط Android'), subtitle: Text('خواندن اعلان‌ها و اجرای برنامه‌ها از این مسیر فقط روی Android پشتیبانی می‌شود.'))),
      const Text('اعلان‌های فعال', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('برای دیدن اعلان‌ها باید خودت دسترسی Notification Access را در تنظیمات Android فعال کنی. جارویس اعلان‌ها را به سرور نمی‌فرستد و در این صفحه ذخیره دائمی نمی‌کند.', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 10),
      if (loading) const LinearProgressIndicator(),
      if (!loading && bridge.supported) Card(child: ListTile(
        leading: Icon(enabled ? Icons.verified_user : Icons.lock_outline),
        title: Text(enabled ? 'دسترسی فعال است' : 'دسترسی فعال نیست'),
        subtitle: const Text('فعال‌سازی کاملاً اختیاری است و هر زمان می‌توانی آن را لغو کنی.'),
        trailing: TextButton(onPressed: _openSettings, child: const Text('تنظیمات')),
      )),
      if (enabled && notifications.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('اعلان فعالی برای نمایش پیدا نشد.')),
      ...notifications.map((n) => Card(child: ListTile(
        title: Text(n['title']?.isNotEmpty == true ? n['title']! : (n['package'] ?? 'اعلان')),
        subtitle: Text('${n['text'] ?? ''}\n${n['package'] ?? ''}', maxLines: 4, overflow: TextOverflow.ellipsis),
      ))),
      const Divider(height: 32),
      const Text('اجرای یک برنامه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const Text('شناسه بسته برنامه را وارد کن؛ جارویس فقط صفحه اصلی همان برنامه را باز می‌کند و کنترل داخلی آن را به‌دست نمی‌گیرد.', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 10),
      TextField(controller: packageController, decoration: const InputDecoration(labelText: 'Package name', hintText: 'com.example.app')),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: bridge.supported ? _launchApp : null, icon: const Icon(Icons.open_in_new), label: const Text('بازکردن برنامه')),
      const SizedBox(height: 12),
      const Text('محدودیت: این قابلیت به شناسه بسته‌ای نیاز دارد که خودت وارد می‌کنی. دسترسی گسترده به فهرست همه برنامه‌های نصب‌شده درخواست نمی‌شود.', style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );
}
