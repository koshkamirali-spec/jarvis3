class ChatMessage {
  final String role;
  final String text;
  final DateTime createdAt;
  const ChatMessage({required this.role, required this.text, required this.createdAt});

  Map<String, dynamic> toJson() => {
    'role': role, 'text': text, 'createdAt': createdAt.toIso8601String()
  };
  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
    role: json['role'] as String,
    text: json['text'] as String,
    createdAt: DateTime.parse(json['createdAt'] as String),
  );
}
