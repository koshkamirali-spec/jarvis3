import 'package:flutter/material.dart';

class JarvisTheme {
  static const background = Color(0xFF080A12);
  static const panel = Color(0xFF141827);
  static const cyan = Color(0xFF35DDF5);
  static const purple = Color(0xFF9A72FF);
  static const gold = Color(0xFFE8C56A);
  static final dark = ThemeData(
    brightness: Brightness.dark, scaffoldBackgroundColor: background,
    colorScheme: const ColorScheme.dark(primary: cyan, secondary: purple, surface: panel),
    appBarTheme: const AppBarTheme(backgroundColor: background, foregroundColor: Colors.white, centerTitle: false),
    cardTheme: CardThemeData(color: panel, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0x2235DDF5)))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: panel, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
    useMaterial3: true,
  );
}
