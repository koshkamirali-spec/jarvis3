import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';

class ReminderService {
 static final ReminderService instance=ReminderService._(); ReminderService._();
 final FlutterLocalNotificationsPlugin _plugin=FlutterLocalNotificationsPlugin(); bool _ready=false;
 Future<void> initialize() async {if(_ready)return;tzdata.initializeTimeZones();try{final zone=await FlutterTimezone.getLocalTimezone();tz.setLocalLocation(tz.getLocation(zone));}catch(_){tz.setLocalLocation(tz.getLocation('UTC'));}const android=AndroidInitializationSettings('@mipmap/ic_launcher');const settings=InitializationSettings(android:android,iOS:DarwinInitializationSettings());await _plugin.initialize(settings);_ready=true;}
 Future<bool> requestPermission() async {await initialize();final android=_plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();final granted=await android?.requestNotificationsPermission();final ios=_plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();final iosGranted=await ios?.requestPermissions(alert:true,badge:true,sound:true);return (granted??true) && (iosGranted??true);}
 Future<void> schedule({required int id,required String title,required String body,required DateTime when}) async {await initialize();await _plugin.zonedSchedule(id,title,body,tz.TZDateTime.from(when,tz.local),const NotificationDetails(android:AndroidNotificationDetails('jarvis_reminders','JARVIS Reminders',channelDescription:'یادآورهای زمان‌بندی‌شده',importance:Importance.high,priority:Priority.high),iOS:DarwinNotificationDetails()),androidScheduleMode:AndroidScheduleMode.inexactAllowWhileIdle,uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);}
 Future<void> cancel(int id) async {await initialize();await _plugin.cancel(id);}
}
