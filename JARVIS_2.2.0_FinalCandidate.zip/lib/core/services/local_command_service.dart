import 'dart:math' as math;

/// Safe, on-device commands that do not require the AI backend.
/// Device actions are delegated to the native bridge and always open a
/// user-visible system screen (dialer/SMS/settings); they never send anything.
class LocalCommandService {
  String? answer(String raw) {
    final text = raw.trim().toLowerCase();
    if (text.isEmpty) return null;
    final now = DateTime.now();
    if (RegExp(r'^(ساعت چنده|ساعت الان|time now|what time is it)\??$').hasMatch(text)) {
      final h = now.hour.toString().padLeft(2, '0');
      final m = now.minute.toString().padLeft(2, '0');
      return 'الان ساعت $h:$m است.';
    }
    if (RegExp(r'^(امروز چندمه|تاریخ امروز|تاریخ چنده|today date|what date is it)\??$').hasMatch(text)) {
      return 'تاریخ امروز: ${now.year}/${now.month.toString().padLeft(2, '0')}/${now.day.toString().padLeft(2, '0')}';
    }
    final match = RegExp(r'^(?:حساب کن|محاسبه کن|calculate)\s+(.+)$').firstMatch(raw.trim());
    if (match != null) {
      final expression = match.group(1)!.replaceAll('×', '*').replaceAll('÷', '/').replaceAll('−', '-');
      try {
        final value = _ExpressionParser(expression).parse();
        if (!value.isFinite) return 'نتیجه عددی معتبر نیست.';
        return 'نتیجه: ${value == value.roundToDouble() ? value.toInt() : value}';
      } catch (_) {
        return 'عبارت ریاضی قابل محاسبه نیست. نمونه: «حساب کن ۱۲ + ۵ × ۳»';
      }
    }
    return null;
  }
}

class _ExpressionParser {
  _ExpressionParser(String input) : tokens = _tokenize(input);
  final List<String> tokens;
  int index = 0;
  static List<String> _tokenize(String input) {
    final normalized = input
        .replaceAll('۰','0').replaceAll('۱','1').replaceAll('۲','2').replaceAll('۳','3')
        .replaceAll('۴','4').replaceAll('۵','5').replaceAll('۶','6').replaceAll('۷','7')
        .replaceAll('۸','8').replaceAll('۹','9').replaceAll('٫','.')
        .replaceAll('،', '.').replaceAll(' ', '');
    final result = <String>[];
    var i = 0;
    while (i < normalized.length) {
      final rest = normalized.substring(i);
      final number = RegExp(r'^\d+(?:\.\d+)?').firstMatch(rest);
      if (number != null) { result.add(number.group(0)!); i += number.group(0)!.length; continue; }
      final c = normalized[i];
      if ('+-*/()'.contains(c)) { result.add(c); i++; continue; }
      throw const FormatException('invalid token');
    }
    return result;
  }
  double parse() {
    final value = _sum();
    if (index != tokens.length) throw const FormatException('unexpected token');
    return value;
  }
  double _sum() {
    var value = _product();
    while (_take('+') || _take('-')) {
      final op = tokens[index - 1];
      final rhs = _product();
      value = op == '+' ? value + rhs : value - rhs;
    }
    return value;
  }
  double _product() {
    var value = _factor();
    while (_take('*') || _take('/')) {
      final op = tokens[index - 1];
      final rhs = _factor();
      if (op == '/' && rhs == 0) throw const FormatException('division by zero');
      value = op == '*' ? value * rhs : value / rhs;
    }
    return value;
  }
  double _factor() {
    if (_take('+')) return _factor();
    if (_take('-')) return -_factor();
    if (_take('(')) { final value = _sum(); if (!_take(')')) throw const FormatException('missing )'); return value; }
    if (index >= tokens.length) throw const FormatException('missing value');
    final token = tokens[index++];
    final value = double.tryParse(token);
    if (value == null || !value.isFinite || value.abs() > math.pow(10, 12)) throw const FormatException('invalid number');
    return value;
  }
  bool _take(String token) { if (index < tokens.length && tokens[index] == token) { index++; return true; } return false; }
}
