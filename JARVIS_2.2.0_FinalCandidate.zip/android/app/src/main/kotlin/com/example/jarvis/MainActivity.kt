package com.example.jarvis

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import io.flutter.plugin.common.EventChannel
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "com.jarvis.ai/device"
    private var wakeEventSink: EventChannel.EventSink? = null
    private var pendingWakeEvent = false

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("jarvis_wake_detected", false)) emitWakeDetected()
    }

    private fun emitWakeDetected() {
        if (wakeEventSink != null) wakeEventSink?.success("wake_detected") else pendingWakeEvent = true
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "com.jarvis.ai/wake_events")
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    wakeEventSink = events
                    if (pendingWakeEvent) { pendingWakeEvent = false; events?.success("wake_detected") }
                }
                override fun onCancel(arguments: Any?) { wakeEventSink = null }
            })
        if (intent.getBooleanExtra("jarvis_wake_detected", false)) pendingWakeEvent = true
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "hasNotificationAccess" -> result.success(isNotificationAccessEnabled())
                    "startWakeWordService" -> {
                        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                            result.error("MIC_PERMISSION", "Microphone permission is required", null)
                        } else {
                            try {
                                val serviceIntent = Intent(this, JarvisWakeWordService::class.java).setAction(JarvisWakeWordService.ACTION_START)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                                result.success(true)
                            } catch (e: Exception) { result.error("WAKE_START_FAILED", e.message, null) }
                        }
                    }
                    "stopWakeWordService" -> {
                        startService(Intent(this, JarvisWakeWordService::class.java).setAction(JarvisWakeWordService.ACTION_STOP))
                        result.success(true)
                    }
                    "isWakeWordServiceRunning" -> result.success(JarvisWakeWordService.running)
                    "openNotificationAccessSettings" -> {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        result.success(true)
                    }
                    "getActiveNotifications" -> {
                        if (!isNotificationAccessEnabled()) {
                            result.error("NO_ACCESS", "Notification access is not enabled by the user", null)
                        } else {
                            result.success(JarvisNotificationListener.activeItems())
                        }
                    }
                    "openApp" -> {
                        val packageName = call.argument<String>("packageName")?.trim().orEmpty()
                        if (packageName.isBlank()) {
                            result.error("BAD_PACKAGE", "Package name is required", null)
                        } else {
                            val launch = packageManager.getLaunchIntentForPackage(packageName)
                            if (launch == null) result.error("NOT_FOUND", "No launchable app found", null)
                            else {
                                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                startActivity(launch)
                                result.success(true)
                            }
                        }
                    }
                    "openAppSettings" -> {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName")))
                        result.success(true)
                    }
                    "openSystemSettings" -> {
                        val action = when (call.argument<String>("section")) {
                            "wifi" -> Settings.ACTION_WIFI_SETTINGS
                            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                            "display" -> Settings.ACTION_DISPLAY_SETTINGS
                            "sound" -> Settings.ACTION_SOUND_SETTINGS
                            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                            else -> Settings.ACTION_SETTINGS
                        }
                        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        result.success(true)
                    }
                    "openDialer" -> {
                        val number = call.argument<String>("number")?.trim().orEmpty()
                        val uri = if (number.isEmpty()) Uri.parse("tel:") else Uri.fromParts("tel", number, null)
                        startActivity(Intent(Intent.ACTION_DIAL, uri))
                        result.success(true)
                    }
                    "composeSms" -> {
                        val number = call.argument<String>("number")?.trim().orEmpty()
                        val body = call.argument<String>("body")?.take(2000).orEmpty()
                        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(number)}"))
                        intent.putExtra("sms_body", body)
                        startActivity(intent)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(":").any { it.equals(componentName.flattenToString(), ignoreCase = true) }
    }
}
