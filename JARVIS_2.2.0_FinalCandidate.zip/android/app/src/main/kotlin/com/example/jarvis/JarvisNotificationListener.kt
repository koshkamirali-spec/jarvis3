package com.example.jarvis

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Bundle

/** Reads currently active notifications only after the user explicitly grants Notification Access. */
class JarvisNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile private var instance: JarvisNotificationListener? = null

        fun activeItems(): List<Map<String, String>> {
            val service = instance ?: return emptyList()
            return try {
                service.activeNotifications.orEmpty().take(40).map { sbn ->
                    val extras: Bundle = sbn.notification.extras
                    mapOf(
                        "package" to sbn.packageName,
                        "title" to (extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""),
                        "text" to (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
                            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""),
                        "postedAt" to sbn.postTime.toString()
                    )
                }
            } catch (_: SecurityException) { emptyList() }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) { /* No background forwarding or storage. */ }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { /* No background forwarding or storage. */ }
}
