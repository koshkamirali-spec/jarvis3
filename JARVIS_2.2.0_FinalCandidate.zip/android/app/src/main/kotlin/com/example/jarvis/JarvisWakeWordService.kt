package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * User-started, visible foreground microphone service.
 * Uses Android's speech recognizer to detect the wake phrase; this is not an
 * offline DSP wake-word engine and availability/network use depends on device services.
 */
class JarvisWakeWordService : Service(), RecognitionListener {
    companion object {
        const val ACTION_START = "com.jarvis.ai.wake.START"
        const val ACTION_STOP = "com.jarvis.ai.wake.STOP"
        const val CHANNEL_ID = "jarvis_wake_channel"
        const val NOTIFICATION_ID = 4201
        @Volatile var running: Boolean = false
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var wakeDetected = false
    private var restartAttempts = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopWakeService(); return START_NOT_STICKY }
            ACTION_START -> {
                wakeDetected = false
                // Started only from the visible Settings screen after the user grants microphone access.
                running = true
                startForeground(NOTIFICATION_ID, buildNotification("در حال گوش‌دادن به «هی جارویس»"))
                beginRecognition()
            }
        }
        return START_NOT_STICKY
    }

    private fun beginRecognition() {
        if (!running || wakeDetected || listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("تشخیص گفتار روی این دستگاه در دسترس نیست")
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            listening = true
            recognizer?.startListening(request)
        } catch (_: Exception) {
            listening = false
            scheduleRestart()
        }
    }

    override fun onReadyForSpeech(params: Bundle?) { restartAttempts = 0 }
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { listening = false; scheduleRestart(500) }

    override fun onError(error: Int) {
        listening = false
        // Common no-speech / timeout errors are expected during continuous listening.
        scheduleRestart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1800 else 900)
    }

    override fun onResults(results: Bundle?) {
        listening = false
        val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        if (phrases.any { containsWakePhrase(it) }) {
            wakeDetected = true
            recognizer?.cancel()
            recognizer?.destroy()
            recognizer = null
            updateNotification("«هی جارویس» شنیده شد؛ برای بازکردن دستیار اعلان را لمس کن")
        } else {
            scheduleRestart(350)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val phrases = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        if (phrases.any { containsWakePhrase(it) }) {
            wakeDetected = true
            listening = false
            recognizer?.cancel()
            recognizer?.destroy()
            recognizer = null
            updateNotification("«هی جارویس» شنیده شد؛ برای بازکردن دستیار اعلان را لمس کن")
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    private fun containsWakePhrase(raw: String): Boolean {
        val normalized = raw.lowercase(Locale.ROOT)
            .replace('ي', 'ی').replace('ك', 'ک')
            .replace("\u200c", " ").replace("\u200f", "")
            .replace(Regex("[،,.!؟?؛:]"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return normalized.contains("hey jarvis") || normalized.contains("hey jarvis") ||
            normalized.contains("هی جارویس") || normalized.contains("هی جارویس") ||
            normalized.contains("ای جارویس") || normalized.contains("هی جارويس")
    }

    private fun scheduleRestart(delay: Long = 700) {
        if (!running || wakeDetected) return
        restartAttempts = (restartAttempts + 1).coerceAtMost(6)
        val backoff = delay * restartAttempts.coerceAtMost(3)
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ beginRecognition() }, backoff)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "JARVIS Wake Word", NotificationManager.IMPORTANCE_LOW)
            channel.description = "اعلان دائمی هنگام فعال‌بودن تشخیص عبارت بیدارباش جارویس"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("jarvis_wake_detected", wakeDetected)
        }
        val immutableFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        val openPending = PendingIntent.getActivity(this, 1, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag)
        val stopIntent = Intent(this, JarvisWakeWordService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag)
        val builder = Notification.Builder(this)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("J.A.R.V.I.S")
            .setContentText(message)
            .setContentIntent(openPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "توقف", stopPending)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) builder.setChannelId(CHANNEL_ID)
        return builder.build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun stopWakeService() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        listening = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        stopWakeService()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
